<?php
$_lang['modx_news'] = 'Новости MODx';
$_lang['security_notices'] = 'Уведомления о безопасности';
$_lang['welcome_messages'] = 'Всего сообщений в вашем почтовом ящике<strong>%d</strong>, из них не прочитано <strong>%s</strong>.';
$_lang['welcome_title'] = 'Добро пожаловать в систему управления сайтом MODx';
$_lang['yourinfo_message'] = 'Этот раздел содержит некоторые данные о вас:';
$_lang['yourinfo_previous_login'] = 'Последняя авторизация:';
$_lang['yourinfo_title'] = 'Информация о вас';
$_lang['yourinfo_total_logins'] = 'Всего авторизаций:';
$_lang['yourinfo_username'] = 'Вы авторизованы как:';
