<?php
/**
 * System Events Swedish lexicon topic
 *
 * @language sv
 * @package modx
 * @subpackage lexicon
 */
$_lang['clear'] = 'Rensa';
$_lang['error_log'] = 'Fellogg';
$_lang['error_log_desc'] = 'Här är felloggen för MODx Revolution:';
$_lang['system_events'] = 'Systemhändelser';
$_lang['priority'] = 'Prioritet';