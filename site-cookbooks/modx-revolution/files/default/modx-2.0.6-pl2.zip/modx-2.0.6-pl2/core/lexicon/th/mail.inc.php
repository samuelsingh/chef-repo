<?php
/**
 * Mail Thai lexicon topic
 *
 * @language th
 * @package modx
 * @subpackage lexicon
 
  * @author Mr.Kittipong Intaboot COE#18,KKU
 * @updated 2010-07-21
 */
$_lang['mail_err_address_ns'] = 'การส่งจดหมายคุณต้องมีที่อยู่อีเมล์ของผู้รับ';
$_lang['mail_err_derive_getmailer'] = 'พยายามเรียกฟังก์ชันนามธรรม _getMailer() ในคลาส modMail คุณต้องจัดเตรียมฟังก์ชันนี้ในคลาส modMail';
$_lang['mail_err_attr_nv'] = '[[+attr]] เป็นคุณลักษณะของ PHPMailer ที่ไม่ถูกต้องและกำลังถูกละเว้นในการจัดเตรียม';

$_lang['mail_err_unset_spec'] = 'modPHPMailer ไม่รองรับการระบุที่อยู่ใช้ reset() เพื่อล้างผู้รับทั้งหมด แล้วเพิ่มผู้รับที่คุณต้องการอีกครั้ง';