<?php
/**
 * System Events French lexicon topic
 *
 * @language fr
 * @package modx
 * @subpackage lexicon
 */
$_lang['clear'] = 'Effacer';
$_lang['error_log'] = 'Log d\'erreurs';
$_lang['error_log_desc'] = 'Voici le fichier d\'erreurs de MODx Revolution:';
$_lang['system_events'] = 'Événements système';
$_lang['priority'] = 'Priorité';