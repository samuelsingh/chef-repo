<?php
/**
 * System Events Thai lexicon topic
 *
 * @language th
 * @package modx
 * @subpackage lexicon
 
  * @author Mr.Kittipong Intaboot COE#18,KKU
 * @updated 2010-07-21
 */
$_lang['clear'] = 'ล้าง';
$_lang['error_log'] = 'บันทึกข้อผิดพลาด';
$_lang['error_log_desc'] = 'นี่คือบันทึกข้อผิดพลาดสำหรับ MODx Revolution:';
$_lang['system_events'] = 'เหตุการณ์ของระบบ';
$_lang['priority'] = 'การจัดลำดับความสำคัญ';