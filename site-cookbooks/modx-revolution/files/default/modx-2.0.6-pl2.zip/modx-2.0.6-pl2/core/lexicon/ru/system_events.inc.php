<?php
$_lang['clear'] = 'Очистить';
$_lang['error_log'] = 'Журнал ошибок';
$_lang['error_log_desc'] = 'Это журнал ошибок для MODx Revolution:';
$_lang['system_events'] = 'Системные события';
$_lang['priority'] = 'Приоритетность';
