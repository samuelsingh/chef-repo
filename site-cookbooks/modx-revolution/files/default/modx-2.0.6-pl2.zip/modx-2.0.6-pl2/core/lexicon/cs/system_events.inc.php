<?php
/**
 * System Events Czech lexicon topic
 *
 * @language cs
 * @package modx
 * @subpackage lexicon
 *
 * @author modxcms.cz
 * @updated 2010-06-01
 */
$_lang['clear'] = 'Vymazat';
$_lang['error_log'] = 'Chybové zprávy';
$_lang['error_log_desc'] = 'Zde jsou chybové zprávy z MODx Revolution:';
$_lang['system_events'] = 'Systémové události';
$_lang['priority'] = 'Priorita';