<?php
/**
 * System Events Japanese lexicon topic
 *
 * @language ja
 * @package modx
 * @subpackage lexicon
 * @author Nick http://smallworld.west-tokyo.com
 */
$_lang['clear'] = 'クリア';
$_lang['error_log'] = 'エラーログ';
$_lang['error_log_desc'] = 'MODx Revolutionのエラーログ:';
$_lang['system_events'] = 'システムイベント';
$_lang['priority'] = 'プライオリティ';