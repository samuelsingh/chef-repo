<?php
$_lang['autotag'] = 'Авто-метка - Auto-Tag';
$_lang['text'] = 'Текст - Text';
$_lang['textarea'] = 'Текстовая область - Textarea';
$_lang['textareamini'] = 'Текстовая область (мини) - Textarea (Mini)';
$_lang['richtext'] = 'Редактор - RichText';
$_lang['dropdown'] = 'Выпадающий список - DropDown List Menu';
$_lang['listbox'] = 'Список (одиночный выбор) - Listbox (Single-Select)';
$_lang['listbox-multiple'] = 'Список (множественный выбор) - Listbox (Multi-Select)';
$_lang['option'] = 'Переключатель - Radio Options';
$_lang['checkbox'] = 'Флажок - Check Box';
$_lang['image'] = 'Изображение -Image';
$_lang['file'] = 'Файл - File';
$_lang['url'] = 'URL';
$_lang['email'] = 'Адрес электронной почты - Email';
$_lang['number'] = 'Число - Number';
$_lang['date'] = 'Дата - Date';
$_lang['tag'] = 'Метка -Tag';
