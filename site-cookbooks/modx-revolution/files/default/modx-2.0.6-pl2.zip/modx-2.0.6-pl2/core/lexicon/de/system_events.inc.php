<?php
/**
 * @package modx
 * @subpackage lexicon

 * @language de
 * @namespace core
 * @topic system_events
 */
$_lang['clear'] = 'Löschen';
$_lang['error_log'] = 'Fehlerprotokoll';
$_lang['error_log_desc'] = 'Hier ist das Fehlerprotokoll für MODx Revolution:';
$_lang['system_events'] = 'System-Ereignisse';
$_lang['priority'] = 'Priorität';
