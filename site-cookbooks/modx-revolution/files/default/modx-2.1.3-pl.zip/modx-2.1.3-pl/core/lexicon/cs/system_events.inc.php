<?php
/**
 * System Events Czech lexicon topic
 *
 * @language cs
 * @package modx
 * @subpackage lexicon
 *
 * @author modxcms.cz
 * @updated 2011-03-30
 */
$_lang['clear'] = 'Vymazat';
$_lang['error_log'] = 'Chybové zprávy';
$_lang['error_log_desc'] = 'Chybové zprávy z MODX Revolution:';
$_lang['system_events'] = 'Systémové události';
$_lang['priority'] = 'Priorita';