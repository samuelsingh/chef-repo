﻿<?php
/**
 * Welcome Spanish lexicon topic
 *
 * @language es_MX
 * @package modx
 * @subpackage lexicon
 */
$_lang['modx_news'] = 'Noticias MODX';
$_lang['security_notices'] = 'Notas de Seguridad';
$_lang['welcome_messages'] = 'Tu Bandeja de Entrada contiene <strong>%d</strong> mensaje(s), de los cuales <strong>%s</strong> no has leído.';
$_lang['welcome_title'] = 'Bienvenido a tu Admin de Contenido MODX';
$_lang['yourinfo_message'] = 'Esta sección muestra información acerca de ti:';
$_lang['yourinfo_previous_login'] = 'Tu última entrada:';
$_lang['yourinfo_title'] = 'Tu info';
$_lang['yourinfo_total_logins'] = 'Número total de entradas:';
$_lang['yourinfo_username'] = 'Estás registrado como:';