<?php
/**
 * Mail French lexicon topic
 *
 * @language fr
 * @package modx
 * @subpackage lexicon
 */
$_lang['mail_err_address_ns'] = 'Vous devez fournir une adresse email de destination.';
$_lang['mail_err_derive_getmailer'] = 'Essai d\'appel de fonction abstraite _getMailer() dans la classe modMail. Vous devez implémenter cette fonction dans un dérivé de modMail.';
$_lang['mail_err_attr_nv'] = '[[+attr]] n\'est pas un attribut valide de PHPMailer et son implémentation sera ignorée.';
$_lang['mail_err_unset_spec'] = 'modPHPMailer ne supporte pas la "non spécification" de cette "adresse spécifique". Utilisez reset() pour effacer tous les destinataires et ajouter ceux à qui vous voulez écrire.';