
This directory contains GeoDirectory Server extensions.
It may be empty if no extensions are installed.
